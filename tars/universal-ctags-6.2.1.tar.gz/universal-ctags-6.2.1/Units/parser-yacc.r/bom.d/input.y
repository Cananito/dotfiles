﻿%{
int x;
%}

%%

%%
int y;
