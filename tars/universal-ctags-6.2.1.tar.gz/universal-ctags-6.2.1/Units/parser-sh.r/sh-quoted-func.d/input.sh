echo 'bug(){ :; }'
