c<<A <<B
