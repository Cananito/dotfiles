env> php<<E
