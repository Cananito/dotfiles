`f<<-` <- function() {
       1
}
